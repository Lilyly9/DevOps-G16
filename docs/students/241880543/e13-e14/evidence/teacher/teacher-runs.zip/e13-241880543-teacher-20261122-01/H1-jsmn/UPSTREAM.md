Original project: https://github.com/zserge/jsmn
Pinned upstream commit: 25647e692c7906b96ffd2b05ca54c097948e879c
The course fixture retains the upstream core and license; main.c, Makefile, Dockerfile and the helper wrapper are course additions.
Upstream file hashes: {"jsmn.h": "c04533e9181e1e33baceb0f55ac449b05145bb936e8c68cc77dfe0d8277514fb"}
