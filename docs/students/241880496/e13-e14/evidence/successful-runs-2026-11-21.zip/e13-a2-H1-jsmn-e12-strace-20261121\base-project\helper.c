#include <string.h>
#include "jsmn.h"
int helper(void) {
    const char *json = "{\"n\":7}";
    jsmn_parser parser;
    jsmntok_t tokens[8];
    jsmn_init(&parser);
    int count = jsmn_parse(&parser, json, strlen(json), tokens, 8);
    return count == 3 ? 0 : 1;
}
